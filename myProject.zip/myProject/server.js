//  
//  hyunilPark
//  leehan2121@gmail.com
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();

/*
────────────────────────────────
기본 미들웨어
────────────────────────────────
*/

// CORS 허용
// 프론트(React)가 다른 포트/도메인에서 접근 가능하게 함
app.use(cors());

// JSON 요청 파싱
// req.body 사용 가능
app.use(express.json());

/*
────────────────────────────────
정적 파일 공개 (🔥 중요 🔥)
────────────────────────────────
*/

// uploads 폴더를 URL로 접근 가능하게 설정
// http://서버주소:포트/uploads/파일명
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

/*
────────────────────────────────
라우터 연결
────────────────────────────────
*/

const routes = require('./routes');

// 모든 API는 /api 로 시작
// 예: POST /api/upload
app.use('/api', routes);

/*
────────────────────────────────
기본 루트
────────────────────────────────
*/

// 서버 살아있는지 확인용
app.get('/', (req, res) => {
  res.send('✅ Server is running');
});

/*
────────────────────────────────
서버 실행
────────────────────────────────
*/

const PORT = 3000;
const HOST = '0.0.0.0'; // 내부 IP 접근 허용

app.listen(PORT, HOST, () => {
  console.log(`🚀 Server running`);
  console.log(`👉 Local    : http://localhost:${PORT}`);
  console.log(`👉 Network  : http://192.168.0.57:${PORT}`);
});