# generator.py
import json
import re
import requests
from pathlib import Path
from datetime import datetime

from prompts import build_prompt_json

DEBUG_DIR = Path("debug")
RAW_DIR = DEBUG_DIR / "llm_raw"
RAW_DIR.mkdir(parents=True, exist_ok=True)

def _ts():
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def _save_raw(topic_tag: str, stage: str, text: str):
    safe = re.sub(r"[^a-zA-Z0-9_\-()가-힣]", "_", topic_tag)[:80]
    p = RAW_DIR / f"{_ts()}__{safe}__{stage}.txt"
    with open(p, "w", encoding="utf-8") as f:
        f.write(text or "")

def _normalize_base_url(ollama_url: str) -> str:
    u = (ollama_url or "").strip().rstrip("/")
    if u.endswith("/api"):
        u = u[:-4]
    return u

def _get_tags(base: str, timeout=5) -> dict:
    r = requests.get(f"{base}/api/tags", timeout=timeout)
    r.raise_for_status()
    return r.json()

def _model_exists(tags_json: dict, model: str) -> bool:
    want = (model or "").strip()
    if not want:
        return False

    models = tags_json.get("models") or []
    names = []
    for m in models:
        n = (m.get("name") or "").strip()
        if n:
            names.append(n)

    if want in names:
        return True

    # "llama3.2:3b" vs "llama3.2:3b-instruct" 같은 건 별개라 exact가 안전
    # 다만 "llama3.2:3b" vs "llama3.2:3b:latest" 같은 꼬임 방지:
    for n in names:
        if n.startswith(want + ":"):
            return True

    return False

def _extract_json(text: str) -> dict:
    if not text:
        raise ValueError("LLM 응답이 비어있음")

    t = text.strip()

    m = re.search(r"```json\s*(\{.*?\})\s*```", t, flags=re.DOTALL | re.IGNORECASE)
    if m:
        return json.loads(m.group(1))

    m = re.search(r"```\s*(\{.*?\})\s*```", t, flags=re.DOTALL)
    if m:
        return json.loads(m.group(1))

    start = t.find("{")
    end = t.rfind("}")
    if start != -1 and end != -1 and end > start:
        return json.loads(t[start:end + 1].strip())

    raise ValueError("LLM 응답에서 JSON을 추출하지 못함")

def _fallback_parse_text(raw: str, article_title: str) -> tuple[str, str]:
    if not raw:
        return (article_title or "(제목 없음)", "(본문 없음)")

    text = raw.strip()
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if not lines:
        return (article_title or "(제목 없음)", text)

    first = lines[0]
    if first == "{" or first.startswith("{") or first.startswith("```") or first.lower().startswith("json"):
        return (article_title or "(제목 없음)", text)

    title = first[:80]
    body = "\n".join(lines[1:]).strip() or text
    return (title, body)

def generate_post_with_ollama(category, article, ollama_url, model, timeout=60, topic_tag=""):
    article_title = (article.get("title") or "").strip()
    topic_tag = topic_tag or category or "topic"

    prompt = build_prompt_json(category, article)
    _save_raw(topic_tag, "prompt", prompt)

    base = _normalize_base_url(ollama_url)
    url = f"{base}/api/generate"
    payload = {"model": model, "prompt": prompt, "stream": False}

    r = requests.post(url, json=payload, timeout=(10, timeout))

    # ✅ 404는 모델이 없을 때도 자주 발생하므로 tags로 단정
    if r.status_code == 404:
        _save_raw(topic_tag, "http404_body", r.text)

        try:
            tags = _get_tags(base)
            _save_raw(topic_tag, "tags.json", json.dumps(tags, ensure_ascii=False, indent=2))
        except Exception as e:
            _save_raw(topic_tag, "tags_error", repr(e))
            raise RuntimeError(
                f"E_OLLAMA_SERVER_DOWN_OR_BLOCKED: /api/tags 조회 실패. base={base}. {repr(e)}"
            )

        if not _model_exists(tags, model):
            raise RuntimeError(
                "E_OLLAMA_MODEL_NOT_FOUND: /api/generate 가 404입니다. "
                f"현재 설치된 모델이 없습니다(또는 '{model}'이 없음). "
                "해결: `ollama list`로 확인 후 `ollama pull <model>` 실행."
            )

        # 모델이 있는데도 404면 진짜 이상 케이스
        raise RuntimeError(
            "E_OLLAMA_404_UNKNOWN: 모델은 있는데 /api/generate 404. "
            f"base={base}, model={model}. debug/llm_raw/tags.json 과 http404_body 확인"
        )

    r.raise_for_status()

    data = r.json()
    raw = (data.get("response") or "").strip()
    _save_raw(topic_tag, "response", raw)

    try:
        obj = _extract_json(raw)
        title = (obj.get("title") or "").strip()
        body = (obj.get("body") or "").strip()

        if not title or title == "{" or title.startswith("{"):
            title = article_title or "(제목 없음)"
        if not body:
            raise ValueError("JSON body 비어있음")

        return title, body
    except Exception:
        title, body = _fallback_parse_text(raw, article_title)
        if not body or len(body) < 50:
            body = raw or body
        return title, body
