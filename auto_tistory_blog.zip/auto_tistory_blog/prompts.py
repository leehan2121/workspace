# prompts.py
import json

def build_prompt_json(category: str, article: dict) -> str:
    """
    Ollama에게 '결과물만' JSON으로 뽑게 만드는 프롬프트.
    - HTML 금지(<br> 금지)
    - 한국어 고정
    - 섹션/구조/길이 강제
    - 정치 카테고리는 중립 톤 강제
    """

    title = (article.get("title") or "").strip()
    source = (article.get("source") or "").strip()
    url = (article.get("link") or "").strip()
    pubdate = (article.get("date") or "").strip()

    politics_rules = ""
    if category == "politics":
        politics_rules = """
정치 글 추가 규칙:
- 정당/인물에 대한 평가적 단정 금지
- 의도 추측, 내부사정 추정, 감정적 표현 금지
- 사실 요약 + 맥락 설명 위주
- 단정 대신 "~로 전해졌다/~로 알려졌다" 같은 표현 사용
""".strip()

    schema_hint = {
        "title": "string (Korean, clear, reader-friendly headline, <= 70 chars)",
        "body": "string (Korean blog post, plain text, paragraphs separated by blank line \\n\\n)"
    }

    # ✅ 문단 구분 예시를 강하게 제공(순응률↑)
    paragraph_example = (
        "- 요약1\n"
        "- 요약2\n"
        "- 요약3\n\n"
        "## 핵심 요약\n"
        "첫 번째 문단.\n\n"
        "두 번째 문단.\n\n"
        "## 내용 정리\n"
        "세 번째 문단.\n\n"
        "## 의미와 관전 포인트\n"
        "네 번째 문단.\n\n"
        "## 한 줄 결론\n"
        "다섯 번째 문단."
    )

    prompt = f"""
You are a Korean news blogger.

You MUST output ONLY ONE JSON object.
No markdown. No code fences. No explanations. No extra text.

Output JSON schema:
{json.dumps(schema_hint, ensure_ascii=False)}

Hard rules:
- Do NOT include any HTML tags like <br>, <p>, <div>.
- Use plain text only.
- Use \\n\\n (blank line) between paragraphs.
- Write in Korean only. Do not insert random English words.
- The title must be a real headline, not rules or instructions.
- The body must be a complete post. Never stop mid-sentence.

Body requirements (VERY IMPORTANT):
- Start with a 3-line summary (each line starts with "- ").
- Then write the following sections with headings exactly:
  1) "## 핵심 요약"
  2) "## 내용 정리"
  3) "## 의미와 관전 포인트"
  4) "## 한 줄 결론"
- Total length: at least 900 Korean characters.
- At least 5 paragraphs (use blank lines).

You must follow this paragraph separation example style (format example):
{paragraph_example}

{("Additional constraints for politics:\n" + politics_rules) if politics_rules else ""}

News input:
- title: {title}
- source: {source}
- date: {pubdate}
- url: {url}

Now produce the JSON object.
""".strip()

    return prompt
