# image_client_sd.py
import base64
import requests
from pathlib import Path
from datetime import datetime

def _ts():
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def build_sd_prompt(topic_key: str, title: str) -> str:
    topic_hint = {
        "politics": "정치, 국회, 정책, 토론, 중립적 상징",
        "gossip": "연예, 문화, 행사, 스포트라이트, 중립적 상징",
        "social": "사회, 공공, 안전, 법, 중립적 상징",
        "kpop": "음악, 공연, 네온 조명, 스테이지, 중립적 상징",
        "hot": "속보, 헤드라인, 알림, 중립적 상징",
    }.get(topic_key, "뉴스, 이슈, 중립적 상징")

    return f"""
뉴스 블로그 썸네일용 일러스트.
주제 힌트: {topic_hint}
기사 제목: {title}

스타일: clean flat illustration, modern editorial illustration, soft lighting, high resolution
구성: 중앙에 상징적인 오브젝트 1~2개 + 단순 배경
규칙: 텍스트 없음, 로고 없음, 워터마크 없음, 실존인물 사진 느낌 금지, 브랜드 금지
""".strip()

def sd_txt2img(
    prompt: str,
    sd_url: str,
    out_dir: str = "assets",
    width: int = 1024,
    height: int = 576,
    steps: int = 25,
    cfg_scale: float = 6.5,
    timeout_sec: int = 180,
) -> str:
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    endpoint = sd_url.rstrip("/") + "/sdapi/v1/txt2img"

    payload = {
        "prompt": prompt,
        "negative_prompt": "text, watermark, logo, signature, low quality, blurry",
        "width": width,
        "height": height,
        "steps": steps,
        "cfg_scale": cfg_scale,
    }

    r = requests.post(endpoint, json=payload, timeout=(15, timeout_sec))
    r.raise_for_status()
    j = r.json()

    if not j.get("images"):
        raise RuntimeError("SD_API_EMPTY: txt2img 응답에 images가 없습니다.")

    img_b64 = j["images"][0]
    img_bytes = base64.b64decode(img_b64)

    path = Path(out_dir) / f"{_ts()}_{width}x{height}.png"
    path.write_bytes(img_bytes)
    return str(path.resolve())
