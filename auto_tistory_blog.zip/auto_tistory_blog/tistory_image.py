# tistory_image.py
import time
from pathlib import Path
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

def upload_and_insert_image(driver, wait, image_path: str, timeout_sec: int = 30) -> bool:
    p = Path(image_path)
    if not p.exists():
        raise FileNotFoundError(f"IMAGE_NOT_FOUND: {image_path}")
    abs_path = str(p.resolve())

    # 1) 파일 input 찾기 (없으면 버튼 클릭 시도)
    inputs = driver.find_elements(By.CSS_SELECTOR, "input[type='file']")
    if not inputs:
        _try_click_photo_button(driver, wait)
        time.sleep(0.7)
        inputs = driver.find_elements(By.CSS_SELECTOR, "input[type='file']")

    if not inputs:
        raise RuntimeError("TISTORY_IMAGE_NO_INPUT: input[type=file] 없음 (에디터 DOM 확인 필요)")

    # 2) send_keys 가능한 input에 파일 주입
    last = None
    ok = False
    for inp in inputs:
        try:
            driver.execute_script("arguments[0].style.display='block';", inp)
            inp.send_keys(abs_path)
            ok = True
            break
        except Exception as e:
            last = e

    if not ok:
        raise RuntimeError(f"TISTORY_IMAGE_SENDKEYS_FAIL: {repr(last)}")

    # 3) 이미지가 본문에 삽입될 때까지 대기 (에디터마다 다름 → 느슨하게)
    end = time.time() + timeout_sec
    while time.time() < end:
        imgs = driver.find_elements(By.CSS_SELECTOR, "img")
        if imgs and len(imgs) >= 1:
            return True
        time.sleep(0.5)

    # img로 안 잡히는 에디터도 있으니 True로 넘기고, 실패하면 debug html로 잡는다
    return True

def _try_click_photo_button(driver, wait) -> bool:
    candidates = [
        (By.XPATH, "//button[contains(., '사진')]"),
        (By.XPATH, "//button[contains(., '이미지')]"),
        (By.CSS_SELECTOR, "button[aria-label*='사진']"),
        (By.CSS_SELECTOR, "button[aria-label*='이미지']"),
    ]
    for by, sel in candidates:
        try:
            btn = wait.until(EC.element_to_be_clickable((by, sel)))
            btn.click()
            return True
        except Exception:
            continue
    return False
