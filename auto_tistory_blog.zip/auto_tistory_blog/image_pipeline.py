# image_pipeline.py
import config
from image_client_sd import sd_txt2img, build_sd_prompt

def generate_cover_image(topic_key: str, title: str) -> str:
    prompt = build_sd_prompt(topic_key, title)
    return sd_txt2img(
        prompt=prompt,
        sd_url=config.SD_URL,
        out_dir="assets",
        width=config.SD_WIDTH,
        height=config.SD_HEIGHT,
        steps=config.SD_STEPS,
        cfg_scale=config.SD_CFG_SCALE,
        timeout_sec=config.SD_TIMEOUT_SEC,
    )
